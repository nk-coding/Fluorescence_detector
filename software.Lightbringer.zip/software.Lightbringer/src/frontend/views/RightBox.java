package frontend.views;

import javafx.scene.layout.VBox;

public class RightBox extends VBox{
}
