package frontend.views.components;

public interface Plottable {

    double getXValue();

    double getYValue();
}
